<?php
 
/**
 
 * @package Hippo Api
 
 */

/**
 * Plugin Name: Hippo WP API
 * Description: Created by admin.
 * Version: 1.0
 * Author: Admin
 * Author URI: #
 * Text Domain: hippo-domain
 */

class HippoWPApi {

    public function __construct() {
        define( 'PLUGIN_DIR', plugin_dir_path( dirname( __FILE__ ) ) );
        // Add Javascript and CSS for admin screens
        add_action('admin_enqueue_scripts', array($this, 'enqueueAdmin'));
        // Add Javascript and CSS for front-end display
        add_action('wp_enqueue_scripts', array($this, 'enqueueFront'));
        // Create admin page
        add_action('admin_menu', array($this, 'hippo_admin_menu'));
        add_action( 'admin_init', array( $this, 'register_settings' ) );
        //Call shortcode
        add_shortcode('hippo-api-form', array($this, 'hippo_api_form_info'));

        add_action('admin_head', array($this, 'admin_custom_css'));
        //Ajax call
        add_action( 'wp_ajax_nopriv_get_api_info', array($this, 'get_hippo_api_info' ));
        add_action( 'wp_ajax_get_api_info', array($this, 'get_hippo_api_info' ));
    }

    /**
     * Returns all theme options
     *
     * @since 1.0.0
    */
    public static function get_theme_options() {
        return get_option( 'theme_options' );
    }

    /**
     * Returns single theme option
     *
     * @since 1.0.0
    */
    public static function get_theme_option( $id ) {
        $options = self::get_theme_options();
        if ( isset( $options[$id] ) ) {
            return $options[$id];
        }
    }

    /**
     * Register a setting and its sanitization callback.
     *
     * We are only registering 1 setting so we can store all options in a single option as
     * an array. You could, however, register a new setting for each option
     *
     * @since 1.0.0
     */
    public static function register_settings() {
        register_setting( 'theme_options', 'theme_options', array( 'HippoWPApi', 'sanitize' ) );
    }

    public function admin_custom_css() {
        echo '<style>
            .wrap.admin-form {
                width: 100%;
            }
            .wrap.admin-form input[type=text] {
                width: 55%;
            }
        </style>';
    }

    /* ENQUEUE SCRIPTS AND STYLES */
    public function enqueueAdmin() {
        $screen = get_current_screen();
        wp_enqueue_script('admin-script', plugins_url('assets/js/scriptAdmin.js', __FILE__), array('jquery'), '1.0', true);
    }

    public function enqueueFront() {
        wp_enqueue_script('jquery');
        wp_enqueue_script('front-script', plugins_url('assets/js/scriptFront.js', __FILE__), array('jquery'), '1.0', true);
        wp_enqueue_style('front-style', plugins_url('assets/css/styleFront.css', __FILE__), null, '1.0');

        wp_localize_script('front-script', 'AjaxRequest', [
            'ajax_url' => admin_url('admin-ajax.php'),
        ]);

    }

    public function hippo_admin_menu() {
        add_menu_page(
            __( 'Hippo API', 'hippo-domain' ),
            __( 'Hippo API', 'hippo-domain' ),
            'manage_options',
            'hippo-api',
            array($this,'hippo_admin_api_function'),
            'dashicons-schedule',
            3
        );
    }

    public function hippo_admin_api_function() {
        require_once('inc/admin-form.php');
    }

    // Shortcode for Frontend Form
    public function hippo_api_form_info(){
        require_once('inc/frontend-form.php');
    }

    /** aJAX CALL **/
    public function get_hippo_api_info() {
        parse_str($_GET['data'], $arrayData);
        if(isset($arrayData) && !empty($arrayData)){

            $hippoApi = new HippoWPApi();

            $api_url    = $hippoApi::get_theme_option( 'api_url' );
            $auth_token = $hippoApi::get_theme_option( 'auth_token' );

            $firstName = isset($arrayData['firstname']) ? $arrayData['firstname'] : '';
            $lastName = isset($arrayData['lastname']) ? $arrayData['lastname'] : '';
            $email = isset($arrayData['email']) ? $arrayData['email'] : '';
            $phone = isset($arrayData['phone']) ? $arrayData['phone'] : '';
            $unit = isset($arrayData['unit']) ? $arrayData['unit'] : '';
            $city = isset($arrayData['city']) ? $arrayData['city'] : '';
            $zip = isset($arrayData['zipcode']) ? $arrayData['zipcode'] : '';
            $state = isset($arrayData['state']) ? $arrayData['state'] : '';
            $dob = isset($arrayData['dob']) ? $arrayData['dob'] : '';
            $address = isset($arrayData['streetAddress']) ? $arrayData['streetAddress'] : '';
            $house = isset($arrayData['house_val']) ? $arrayData['house_val'] : '';

            $newDate = date("mdY", strtotime($dob));

            $options = 'street='.$address.'&city='.$city.'&state='.$state.'&zip='.$zip.'&first_name='.$firstName.'&last_name='.$lastName.'&email='.$email.'&phone='.$phone.'&date_of_birth='.$newDate.'';

            $api_call = ''.$api_url.'?auth_token='.$auth_token.'&'.$options.'';

            //$api_call = 'https://api.staging.myhippo.io/v1/herd/quote?auth_token=zcXbR1NoE0zoozyuqAa75s5gBATbeiUsbkGhvb5toGiNWUdDjIUkAU5XgDwCRTet&street=435%20Homer%20Ave&city=Palo%20Alto&state=CA&zip=94301&first_name=John&last_name=Gill&email=Test%40test.com&phone=7869885582&date_of_birth=05061979';

            $request = wp_remote_get($api_call);

            $body = wp_remote_retrieve_body( $request );

            $data = json_decode( $body );

            $result = '';

            echo '<pre>'; print_r($data); echo '</pre>';

            if( empty($api_url) ) {
                $result .='<ul class="error main-ul">
                            <li><strong>Please provide API link.</strong></li>
                        </ul>';
            } else if( empty($auth_token) ) {
                $result .='<ul class="error main-ul">
                            <li><strong>Auth token is required.</strong></li>
                        </ul>';
            } else if( !empty($data->errors) ) {
                $result .='<ul class="error main-ul">
                            <li><strong>'.$data->errors[0]->message.'</strong></li>
                        </ul>';
            } else {
                $result .='<ul class="result-lists main-ul">
                            <li><h3 style="text-align: center;">Quote Premium : '.$data->quote_premium.'</h3></li>
                            <li><h3 style="text-align: center;">Coverage A : '.$data->coverage_a.'</h3></li>
                        </ul>';
            }
            echo $result;
            exit;
        }
    }

}

global $hippoApi;

// Create an instance of our class to kick off the whole thing
$hippoApi = new HippoWPApi();

// Helper function to use in your theme to return a theme option value
function prefix_get_theme_option( $id = '' ) {
    return HippoWPApi::get_theme_option( $id );
}