<div class="wrap admin-form">
    <h1><?php esc_html_e( 'Theme Options', 'text-domain' ); ?></h1>
    <form method="post" action="options.php">
        <?php settings_fields( 'theme_options' ); ?>
        <table class="form-table wpex-custom-admin-login-table">
            <?php // Text input example ?>
            <tr valign="top">
                <th scope="row"><?php esc_html_e( 'Auth Token', 'hippo-domain' ); ?></th>
                <td>
                    <?php $value = self::get_theme_option( 'auth_token' ); ?>
                    <input type="text" name="theme_options[auth_token]" value="<?php echo esc_attr( $value ); ?>">
                </td>
            </tr>
            <tr valign="top">
                <th scope="row"><?php esc_html_e( 'API URL', 'hippo-domain' ); ?></th>
                <td>
                    <?php $value = self::get_theme_option( 'api_url' ); ?>
                    <input type="text" name="theme_options[api_url]" value="<?php echo esc_attr( $value ); ?>">
                </td>
            </tr>

        </table>

        <?php submit_button(); ?>

    </form>

</div><!-- .wrap -->