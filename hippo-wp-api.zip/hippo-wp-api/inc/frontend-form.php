<div class="hippo-form">
    <h3>Hippo API Form</h3>
    <div class="resultData"></div>
    <div class="form">
        <form action="#" id="form" class="wp-form">
            <div class="name-field">
                <div class="field">
                    <label for="fname">First Name *</label>
                    <input type="text" id="fname" name="firstname" required="required">
                </div>
                <div class="field">
                    <label for="mname">Middle Name</label>
                    <input type="text" id="mname" name="middlename">
                </div>
                <div class="field">
                    <label for="lname">Last Name *</label>
                    <input type="text" id="lname" name="lastname" required="required">
                </div>
            </div>

            <div class="address-field">
                <div class="field address">
                    <label for="address">Street Address *</label>
                    <input type="text" id="address" name="streetAddress" required="required">
                </div>
                <div class="field">
                    <label for="unit">Unit #</label>
                    <input type="text" id="unit" name="unit">
                </div>
            </div>

            <div class="state-field">
                <div class="field">
                    <label for="city">City *</label>
                    <input type="text" id="city" name="city" required="required">
                </div>
                <div class="field">
                    <label for="state">State *</label>
                    <select name="state">
                        <option value="AL">Alabama</option>
                        <option value="AK">Alaska</option>
                        <option value="AZ">Arizona</option>
                        <option value="AR">Arkansas</option>
                        <option value="CA">California</option>
                        <option value="CO">Colorado</option>
                        <option value="CT">Connecticut</option>
                        <option value="DE">Delaware</option>
                        <option value="DC">District Of Columbia</option>
                        <option value="FL">Florida</option>
                        <option value="GA">Georgia</option>
                        <option value="HI">Hawaii</option>
                        <option value="ID">Idaho</option>
                        <option value="IL">Illinois</option>
                        <option value="IN">Indiana</option>
                        <option value="IA">Iowa</option>
                        <option value="KS">Kansas</option>
                        <option value="KY">Kentucky</option>
                        <option value="LA">Louisiana</option>
                        <option value="ME">Maine</option>
                        <option value="MD">Maryland</option>
                        <option value="MA">Massachusetts</option>
                        <option value="MI">Michigan</option>
                        <option value="MN">Minnesota</option>
                        <option value="MS">Mississippi</option>
                        <option value="MO">Missouri</option>
                        <option value="MT">Montana</option>
                        <option value="NE">Nebraska</option>
                        <option value="NV">Nevada</option>
                        <option value="NH">New Hampshire</option>
                        <option value="NJ">New Jersey</option>
                        <option value="NM">New Mexico</option>
                        <option value="NY">New York</option>
                        <option value="NC">North Carolina</option>
                        <option value="ND">North Dakota</option>
                        <option value="OH">Ohio</option>
                        <option value="OK">Oklahoma</option>
                        <option value="OR">Oregon</option>
                        <option value="PA">Pennsylvania</option>
                        <option value="RI">Rhode Island</option>
                        <option value="SC">South Carolina</option>
                        <option value="SD">South Dakota</option>
                        <option value="TN">Tennessee</option>
                        <option value="TX">Texas</option>
                        <option value="UT">Utah</option>
                        <option value="VT">Vermont</option>
                        <option value="VA">Virginia</option>
                        <option value="WA">Washington</option>
                        <option value="WV">West Virginia</option>
                        <option value="WI">Wisconsin</option>
                        <option value="WY">Wyoming</option>
                    </select>
                </div>
                <div class="field">
                    <label for="zipcode">Zipcode *</label>
                    <input type="text" id="zipcode" name="zipcode" required="required">
                </div>
            </div>

            <div class="dob-field">
                <label for="dob" style="display: block;">Date od Birth *</label>
                <!-- Birth Day -->
                <input type="date" id="dob" name="dob" required="required">
            </div>

            <div class="phone-email-field">
                <div class="field">
                    <label for="phone">Phone Number *</label>
                    <input type="text" id="phone" name="phone" required="required">
                </div>
                <div class="field">
                    <label for="email">Email Address *</label>
                    <input type="email" id="email" name="email" required="required">
                </div>
            </div>

            <div class="houses-field">
                <label style="display: block;padding: 10px;">In this A House, Condo, HO5? *</label>

                <label><div class="house">
                    <div class="img-col">
                        <img src="<?php echo plugins_url( 'assets/images/house.png', dirname(__FILE__) ); ?>" alt="">
                    </div>
                    <div class="radio-col house-col">
                        <h3>House</h3>
                        <p>This is may be a single-family home, townhouse or duplex yor own and live in.</p>
                        <input type="radio" name="house_val" value="house">
                    </div>
                </div></label>
                <label><div class="house">
                    <div class="img-col">
                        <img src="<?php echo plugins_url( 'assets/images/condo.png', dirname(__FILE__) ); ?>" alt="">
                    </div>
                    <div class="radio-col condo-col">
                        <h3>Condo</h3>
                        <p>This is may be a single-family home, townhouse or duplex yor own and live in.</p>
                        <input type="radio" name="house_val" value="condo">
                    </div>
                </div></label>
                <label><div class="house">
                    <div class="img-col">
                        <img src="<?php echo plugins_url( 'assets/images/ho5.png', dirname(__FILE__) ); ?>" alt="">
                    </div>
                    <div class="radio-col ho5-col">
                        <h3>HO5</h3>
                        <p>This is may be a single-family home, townhouse or duplex yor own and live in.</p>
                        <input type="radio" name="house_val" value="ho5">
                    </div>
                </div></label>
            </div>

            <div class="button-field">
                <button id="submitData">Submit</button>
            </div>
        </form>
    </div>
</div>